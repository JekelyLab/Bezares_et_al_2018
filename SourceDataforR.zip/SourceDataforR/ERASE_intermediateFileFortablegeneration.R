
SpeedvsResptypeFullHead<-data.frame(TableResults[Head,"File.name"],TableResults[Head,"Larva_ID"],TableResults[Head,"TimeperFrame"],TableResults[Head,"ProbespeedP"],TableResults[Head,"Relative2max_Elevation"],TableResults[Head,"Closure_Prototroch"],TableResults[Head,"LatencyClosure"],TableResults[Head,"LCloBody"],TableResults[Head,"Elev2Proto"],TableResults[Head,"Elev2Body"],TableResults[Head,"Elev_parapodia"],TableResults[Head,"LatencyElev"],TableResults[Head,"LRElev1stPa"],TableResults[Head,"Coord12"],TableResults[Head,"Coord13"],TableResults[Head,"DurationRest2Elevation"],TableResults[Head,"RespType"],TableResults[Head,"RoundDist"])

names(SpeedvsResptypeFullHead)<-c("Experiment_ID","Larva_ID","Time per frame (ms)","Probe speed (um/ms)","Relative Elevation","Closure Prototroch","Latency Closure Prototroch (ms)","Latency Closure Bodytrochs (ms)","Delay Elevation to prototroch (frames)","Delay Elevation to bodytrochs (frames)","Elevation Parapodia","Latency Elevation (ms)","Delay L<->R 1sg (frames)","Delay 1sg->2sg (frames)","Delay 1sg->3sg (frames)","Duration Rest to maxElevation (ms)","Response type","Rounded distance")

write.table(SpeedvsResptypeFullHead,file = "/Users/LuisBezares/ownCloud/Lab/OneDrive\ -\ University\ of\ Exeter/Writing/StartleCR_paper/Elife_submission/SourceDataforSubmission/SourceData_Fig1G-J.txt",sep = "\t",row.names = F)

SpeedvsResptypeFullPygid<-data.frame(TableResults[Pygid,"File.name"],TableResults[Pygid,"Larva_ID"],TableResults[Pygid,"TimeperFrame"],TableResults[Pygid,"ProbespeedP"],TableResults[Pygid,"Relative2max_Elevation"],TableResults[Pygid,"Closure_Prototroch"],TableResults[Pygid,"LatencyClosure"],TableResults[Pygid,"LCloBody"],TableResults[Pygid,"Elev2Proto"],TableResults[Pygid,"Elev2Body"],TableResults[Pygid,"Elev_parapodia"],TableResults[Pygid,"LatencyElev"],TableResults[Pygid,"LRElev1stPa"],TableResults[Pygid,"Coord12"],TableResults[Pygid,"Coord13"],TableResults[Pygid,"DurationRest2Elevation"],TableResults[Pygid,"RespType"],TableResults[Pygid,"RoundDist"])

names(SpeedvsResptypeFullPygid)<-c("Experiment_ID","Larva_ID","Time per frame (ms)","Probe speed (um/ms)","Relative Elevation","Closure Prototroch","Latency Closure Prototroch (ms)","Latency Closure Bodytrochs (ms)","Delay Elevation to prototroch (frames)","Delay Elevation to bodytrochs (frames)","Elevation Parapodia","Latency Elevation (ms)","Delay L<->R 1sg (frames)","Delay 1sg->2sg (frames)","Delay 1sg->3sg (frames)","Duration Rest to maxElevation (ms)","Response type","Rounded distance")

write.table(SpeedvsResptypeFullPygid,file = "/Users/LuisBezares/ownCloud/Lab/OneDrive\ -\ University\ of\ Exeter/Writing/StartleCR_paper/Elife_submission/SourceDataforSubmission/SourceData_Fig1H.txt",sep = "\t",row.names = F)

SpeedvsResptypePKD11<-data.frame(PKD11Table$File.name,PKD11Table$Larva_ID,PKD11Table$TimeperFrame,PKD11Table$ProbespeedP,PKD11Table$Max.Angle_parapodiaBASE..1st.pair.,PKD11Table$Closure_Prototroch,PKD11Table$Elev_parapodia,PKD11Table$Closest.body.part.to.probe)

names(SpeedvsResptypePKD11)<-c("Experiment_ID","Larva_ID","Time per frame (ms)","Probe speed (um/ms)","Parapodial Elevation (??)","Closure Prototroch","Elevation Parapodia","Stimulation side")

write.table(SpeedvsResptypePKD11,file = "/Users/LuisBezares/ownCloud/Lab/OneDrive\ -\ University\ of\ Exeter/Writing/StartleCR_paper/Elife_submission/SourceDataforSubmission/SourceData_Fig3pkd1.txt",sep = "\t",row.names = F)

SpeedvsResptypePKD21<-data.frame(PKD21Table$File.name,PKD21Table$Larva_ID,PKD21Table$TimeperFrame,PKD21Table$ProbespeedP,PKD21Table$Max.Angle_parapodiaBASE..1st.pair.,PKD21Table$Closure_Prototroch,PKD21Table$Elev_parapodia,PKD21Table$Closest.body.part.to.probe)

names(SpeedvsResptypePKD21)<-c("Experiment_ID","Larva_ID","Time per frame (ms)","Probe speed (um/ms)","Parapodial Elevation (??)","Closure Prototroch","Elevation Parapodia","Stimulation side")

write.table(SpeedvsResptypePKD21,file = "/Users/LuisBezares/ownCloud/Lab/OneDrive\ -\ University\ of\ Exeter/Writing/StartleCR_paper/Elife_submission/SourceDataforSubmission/SourceData_Fig3pkd2.txt",sep = "\t",row.names = F)


Cell<-dcast(Mltocell,Final.CorrFrame~variable)
LB01d2<-approx(Mltocell[grep("LB01d2",Mltocell$variable),"Final.CorrFrame"],Mltocell[grep("LB01d2",Mltocell$variable),"value"],xout = CorrFrame)

LB01d3<-approx(Mltocell[grep("LB01d3",Mltocell$variable),"Final.CorrFrame"],Mltocell[grep("LB01d3",Mltocell$variable),"value"],xout = CorrFrame)

write.table(NormSumFinal,file = "/Users/LuisBezares/ownCloud/Lab/OneDrive\ -\ University\ of\ Exeter/Writing/StartleCR_paper/Elife_submission/SourceData_NormSumFinal.txt",sep = "\t",row.names = F)

writeLines(meltSF,file = "/Users/LuisBezares/ownCloud/Lab/OneDrive\ -\ University\ of\ Exeter/Writing/StartleCR_paper/Elife_submission/MeltSF.txt",row.names = F)

lapply(SummFile, write, "/Users/LuisBezares/ownCloud/Lab/OneDrive\ -\ University\ of\ Exeter/Writing/StartleCR_paper/Elife_submission/SumPoolfile15.txt", append=TRUE)